package hlieb.model.weapons;

public enum WeaponType {
	SPRING, AEG, GAS, GRENADE_LAUNCHER, MELEE;
}
