package hlieb.model.gear;

public interface HelmetAccessories {

}
