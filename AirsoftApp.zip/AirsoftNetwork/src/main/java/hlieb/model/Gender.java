package hlieb.model;

public enum Gender {
	MALE, FEMALE, NOT_SPECIFIED;
}
